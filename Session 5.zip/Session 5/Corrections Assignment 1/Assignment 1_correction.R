############################################################
# Applied Methods
# Assignment 1
# Data manipulation and visualizaton
############################################################
# 0. Load these two libraries
library(dplyr)
library(ggplot2)

# ==========================================================
# 1. The surface of vignard across cantons and time (3pts)
# ==========================================================

# In the data folder, you'll find a fil named "vignard.csv".
################################################################################
###### A. Import this dataset, you should have a dataset with ##################
################################################################################
## 884 observations
## 4 variables
setwd("/Users/maximewalder/Desktop/Teaching_Grading/Applied methods/Assignment 1/data")
vignard_data <- read.csv("vignard data.csv")

# The four variables are:
## Canton: Abréaviation of the canton's name
## Year: The year of observation
## Total: The total surface (in ha) devoted to agriculture in the canton
## Vignard: The total surface (in ha) devoted to vignard in the canton

##############################################################################################################################################
##### B. Create a variable that gives the canton-year share of vignard surface compared to the total surface devoted for agriculture. ########
##############################################################################################################################################
## Divide the vignard surface by the total surface devoted to agriculture?

vignard_data <- vignard_data %>% 
  mutate(share_vignard = Vignard/Total)

######################################################################################################
##### C. In which canton was the surface devoted to agriculture the largest in the year 2000? ########
######################################################################################################


vignard_data %>% 
  filter(Year==2000) %>% 
  arrange(desc(Total)) %>% 
  head(n=1)


vignard_2000 <- vignard_data %>% 
  filter(Year==2000)

vignard_2000[which.max(vignard_2000$Total),]$Canton


###########################################################################################################################################
####### D. In what year did the canton of Zurich (ZH) had the largest share of vignard surface as surface devoted to agriculture? #########
###########################################################################################################################################


vignard_data %>% 
  filter(Canton=="ZH") %>% 
  arrange(desc(share_vignard)) %>% 
  head(n=1)


vignard_ZH <- vignard_data %>% 
  filter(Canton=="ZH")

vignard_ZH[which.max(vignard_ZH$share_vignard),]$Year


####################################################################################################################################################
###### E. Generate an histogram of the agricultural surface in canton since 2000 (do not take into account observations before the year 2000) ######
###### Provide accurate description of the axis in the plot ########################################################################################
####################################################################################################################################################

ggplot(vignard_data %>% 
         filter(Year>1999), 
       aes(x=Total))+
  geom_histogram(color="purple", fill=NA, bins = 50)+
  theme_minimal()+
  labs(x="Total agribultural surface (in ha)",
       y="Number of canton year combinations")

  
#######################################################################################################################################
#### F. Generate a scatter plot with on the x axis, the agricultural surface, and on the y axis, the share of vignard in year 2025. ###
#### Add a line that fits the linear trend between these two variables ################################################################
#### rescale the x axis in log 10 #####################################################################################################
#### Provide accurate description of the acis in the plot #############################################################################
#######################################################################################################################################

ggplot(vignard_data %>% 
         filter(Year==2025), 
       aes(x=Total, y=share_vignard))+
  geom_point(color="black", size = .7)+
  geom_smooth(method="lm")+
  scale_x_log10()+
  labs(x="Agricultural surface (in ha)",
       y="Share of agricultural surface devoted to vignard")+
  theme_minimal()

#############################################################################################################################
####### G. Generate a line plot with the evolution of the sahre of vignard in the canton of Geneva over time. ###############
####### Provide accurate description of the acis in the plot ################################################################
#############################################################################################################################

ggplot(vignard_data %>% 
         filter(Canton=="GE"),
       aes(x=Year, y=share_vignard))+
  geom_line(color="red")+
  labs(x="Year", 
       y="Share of agricultural surface devoted to vignard")+
  theme_minimal()

# ==========================================================
# 2. Expenses in education (3pts)
# ==========================================================

# In the data folder, you'll find a fil named "education expense data.csv".
# You'll also find another file named "education expense data_by educ levels.csv".

################################################################################
###### A. Import these two dataset. ############################################
###### You should have one dataset with ########################################
###### 884 observations ########################################################
###### 3 variables #############################################################

###### And the other with ######################################################
###### 5304 observations #######################################################
###### 4 variables #############################################################
################################################################################


educ_data <- read.csv("education expense data.csv")
educ_data_by_levels <- read.csv("education expense data_by educ levels.csv")


#########################################################################################
##### B. Adapt the following command so you can merge the two datasets ##################
#########################################################################################

# Hint: You may not need to modify the command depending the name you gave your object with the data. 
educ_data_all <- merge(educ_data, educ_data_by_levels, by=c("Canton", "Year"))

## The merged dataset should have 
## 5304 observations
## 5 variables

# The five varables are:
## Canton: Abréaviation of the canton's name
## Year: The year of observaton
## Expenses_total: The total amont spend on education in the canton year
## EducLevel: The level of formation for which the amont was spent
## Expenses: The amont that was spend on the specific degree for a cantonyear


############################################################################################################################
####### C. Create a new variable that gives the share of expense by levels  ################################################
####### Divide the amont spend for a specific level by the overall expenses. Be careful about the class of the variables. ##
############################################################################################################################


educ_data_all <- educ_data_all %>% 
  mutate(Expenses_num = as.numeric(Expenses),
         Expenses_total_num = as.numeric(Expenses_total),
         share_expenses = Expenses_num/Expenses_total_num)

############################################################################################################################
##### D. In which year did the canton of Vaud (VD) had the greatest expense for the level "Hautes écoles"? #################
############################################################################################################################

educ_data_all %>% 
  filter(Canton=="VD" & EducLevel=="Hautes écoles") %>% 
  filter(Expenses_num==max(Expenses_num, na.rm=T))





############################################################################################################################
###### E. Is this the same year as the one the canton spent the most on education overall? If not in what year was that ####
############################################################################################################################


educ_data_all %>% 
  filter(Canton=="VD" & EducLevel=="Hautes écoles") %>% 
  filter(Expenses_total_num==max(Expenses_total_num, na.rm=T))


###################################################################################################################################
### E. provide a plot that describe the distribution of the share of expenses across cantons and year for "École obligatoire". ####
###################################################################################################################################
## Hint: We saw that multiple plots are appropriate to decribe the distribution of such variable, choose one. 


p <- ggplot(educ_data_all %>% 
              filter(EducLevel=="École obligatoire"), 
            aes(x=share_expenses))

p+geom_histogram()
p+geom_boxplot()
p+geom_density()

#####################################################################################################################################################################
#### F. Create a line plot that indicate the evolution of the share of expenses for the different levels of education overtime in the canotn of Lucern (LU). ########
#### give different colors to the different groups and give appropriate labels to the axis and the legend. ##########################################################
#####################################################################################################################################################################


ggplot(educ_data_all %>% 
         filter(Canton == "LU"),
       aes(x=Year, y=share_expenses, color = EducLevel))+
  geom_line()+
  labs(x="Year", y="Share of education expenses", color="Education level")+
  theme_minimal()+
  scale_color_manual(values = c("blue", "grey", "black", "red", "purple", "orange"))+
  theme(legend.position = "bottom")




# ==========================================================
# BONUS. Expense in education and vignard (+1pt)
# ==========================================================


# Create a scatter plot that presents the relationship between the share of vignard and the share of expense for "Hautes écoles" 
# Add a line that presents the linear trend between the variables. 




educ_vignard_data <- merge(vignard_data %>% 
                             filter(Year>=1996), 
                           educ_data_all %>% 
                             filter(Year>=1996 & EducLevel=="Hautes écoles"), 
                           by = c("Canton", "Year"))

ggplot(educ_vignard_data, 
       aes(x=share_vignard, 
           y=share_expenses))+
  geom_point()+
  geom_smooth(method="lm")+
  labs(x="Vignard share in surface (ha)", 
       y="Higher education expenses share")
