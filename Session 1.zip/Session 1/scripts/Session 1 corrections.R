############################################################
# Applied Methods — Session 1
# Introduction to R and RStudio
# Exercises
#
# Goal: practise the basic R commands introduced in class.
# Instructions:
# - Write your answers below each question.
# - Run the code line by line with Cmd/Ctrl + Enter.
# - Read error messages carefully before changing your code.
############################################################


# ==========================================================
# 0. Preparation
# ==========================================================

# Q0.1 Create a folder for today's session on your computer (or download it the website).
# Q0.2 Open RStudio.
# Q0.3 Create a new R script and save it as session_01_exercises.R.
# Q0.4 Make sure this script is inside your session folder.


# ==========================================================
# 1. Simple operations
# ==========================================================

# Q1.1 Compute the following operations in R:
# 12 + 8
12+8
# 35 - 11
35-11
# 6 * 7
6*7
# 144 / 12
144/12
# sqrt(81)
sqrt(81)


# Q1.2 Add parentheses so that R first adds 12 and 8, then divides by 5.
(12+8)/5

# Q1.3 What is the difference between these two commands?
# 10 + 5 * 2
# (10 + 5) * 2

###### The difference is 10. The first commands adds 5*2 to 10, 
###### The second commads multiplies 10+5 by 2

# ==========================================================
# 2. Assign values to objects in the environment
# ==========================================================

# Q2.1 Create an object called my_number containing one number.

my_number <- 45

# Q2.2 Create an object called my_text containing one character string.

my_text <- "my text"

# Q2.3 Create an object called my_factor containing one factor value.
# Hint: use factor().

my_factor <- factor("Cat")


# Q2.4 Use class() to check the class of the three objects.

class(my_number)
class(my_text)
class(my_factor)

# ==========================================================
# 3. Operations with existing objects
# ==========================================================

# Q3.1 Create two objects called budget_2025 and budget_2026.
# Choose any numerical values.

budget_2025 <- 1034
budget_2026 <- 1036

# Q3.2 Create a new object called budget_change containing the difference
# between budget_2026 and budget_2025.

budget_change <- budget_2026 - budget_2025

# Q3.3 Create a new object called budget_growth_percent containing the
# percentage change between budget_2025 and budget_2026.
# Formula: (new value - old value) / old value * 100

budget_growth_percent <- budget_change/budget_2025 *100

# Q3.4 Print the result.

print(budget_growth_percent)

# ==========================================================
# 4. Understanding errors
# ==========================================================

# Q4.1 Run the following line. It should produce an error.
# my_budget + 10

my_budget + 10

# Q4.2 In a comment, explain why the error happened.

#### There is no object called my_budget, so we add 10 to somethign that does not exist

# Q4.3 Fix the error by creating the missing object and running the operation again.

my_budget <- 100

my_budget+10

# Q4.4 Run the following line. Is there an error? What is the result?
# mean(c(1, 2, 3, NA))

mean(c(1, 2, 3, NA))

# Q4.5 Now use the help page for mean().
# Hint: run ?mean in the console.
# Then compute the mean while ignoring the missing value.

mean(c(1, 2, 3, NA), na.rm=T)

# ==========================================================
# 5. Vectors
# ==========================================================

# Q5.1 Create a character vector called commune_names with at least four communes.

commune_names <- c("Confignon", "Lancy", "Veyrier", "Bernex")

# Q5.2 Create a numerical vector called population with one population value for each commune.

population <- c(13, 24, 53, 17)

# Q5.3 Compute the mean, minimum, and maximum population.

mean(population)
min(population)
max(population)

# Q5.4 Extract the first commune name from commune_names.

commune_names[1]

# Q5.5 Extract the first two population values from population.

population[1:2]


# ==========================================================
# 6. Create a data frame
# ==========================================================

# Q6.1 Create a data frame called commune_data using data.frame().
# It should contain the two vectors commune_names and population.

commune_data <- data.frame(name = commune_names, 
                           pop = population)


# Q6.2 Inspect the data frame with the following functions:
# head()
# str()
# summary()
# nrow()
# ncol()


head(commune_data)
str(commune_data)
summary(commune_data)
nrow(commune_data)
ncol(commune_data)

# Q6.3 Create a new variable called population_thousands.
# Hint: you can use the $ operator.

commune_data$population_thousands <- c(1,2,5,4)

# ==========================================================
# 7. Write your first function
# ==========================================================

# Q7.1 Create a function called multiply_4_minus_10.
# The function should multiply a number by 4 and then substract 10, and print the result.

multiply_4_minus_10 <- function(x){
  n <- x*4-10
  print(n)
}


# Q7.2 Test the function with the values 4, 12, and 100.

multiply_4_minus_10(4)
multiply_4_minus_10(12)
multiply_4_minus_10(100)

# Q7.3 Apply the function to the vector population.

multiply_4_minus_10(population)

# ==========================================================
# 8. Install package and load a library
# ==========================================================

# 8.1 Install the devtools package
# install.packages("remotes")

install.packages("remotes")


# 8.2 install the RSwissPos package
# go to https://github.com/maxwaldo/RSwissPos and follow the instruction

remotes::install_github('maxwaldo/RSwissPos')

# 8.3 Load the library in your environment
library(RSwissPos)

# 8.4 Try the getSwissvotes() function from the RSwissPos package

getSwissvotes()

# 8.5 Read the help documentation of the getSwissvotes function with ?getSwissvotes

?getSwissvotes

# What is this function doing? What do you get out of it?

# A data frame with the Swissvotes data

# ==========================================================
# 10. Cumulative challenge
# ==========================================================

# Q10.1 Download the Swissvotes data set and assign it to the object "swissvotes"

swissvotes <- getSwissvotes()

# Q10.2 Which ballot proposal has the greatest share of support by the swiss population?
# Hint: use which.max(). Look at the correct variable to analyze in the Swissvotes codebook.

swissvotes[which.max(swissvotes$volkja.proz),]$titel_kurz_f


# Q10.3 Which ballot proposal has the lowest share of support by the swiss population?
# Hint: use which.min().

swissvotes[which.min(swissvotes$volkja.proz),]$titel_kurz_f

# Q10.4 How many initiative, mandatory and facultative referendums is in the Swissvotes database?

# Various ways to do it. 
# Variable rechtsform tells us the institutional type: 
# 1 = Mandatory referendums, 
# 2 = Facultative referendums,
# 3 = Initiatives,
# 4 = Counter proposals, 
# 5 = "Stichtfrage"

# Table option
table(swissvotes$rechtsform)

# 202 mandatory, 219, facultative, 246 initiatives

# Counting the rows 
nrow(swissvotes[swissvotes$rechtsform==1,]) # Mandatory ref
nrow(swissvotes[swissvotes$rechtsform==2,]) # Facultative ref
nrow(swissvotes[swissvotes$rechtsform==3,]) # Initiative ref

# Clean answer, print the results with the full response:

print(paste("Overall, there has been", 
            nrow(swissvotes[swissvotes$rechtsform==1,]), 
            "mandatory referendums,", 
            nrow(swissvotes[swissvotes$rechtsform==2,]),
            "facultative referendums, and", 
            nrow(swissvotes[swissvotes$rechtsform==3,]), 
            "initiatives, out of the", 
            nrow(swissvotes), 
            "populare ballots the swiss population voted on since 1848."))


