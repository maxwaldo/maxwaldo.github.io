############################################################
# Applied Methods — Session 1
# Introduction to R and RStudio
# Exercises
#
# Goal: practise the basic R commands introduced in class.
# Instructions:
# - Write your answers below each question.
# - Run the code line by line with Cmd/Ctrl + Enter.
# - Read error messages carefully before changing your code.
############################################################


# ==========================================================
# 0. Preparation
# ==========================================================

# Q0.1 Create a folder for today's session on your computer (or download it the website).
# Q0.2 Open RStudio.
# Q0.3 Create a new R script and save it as session_01_exercises.R.
# Q0.4 Make sure this script is inside your session folder.


# ==========================================================
# 1. Simple operations
# ==========================================================

# Q1.1 Compute the following operations in R:
# 12 + 8
# 35 - 11
# 6 * 7
# 144 / 12
# sqrt(81)


# Q1.2 Add parentheses so that R first adds 12 and 8, then divides by 5.

# Q1.3 What is the difference between these two commands?
# 10 + 5 * 2
# (10 + 5) * 2


# ==========================================================
# 2. Assign values to objects in the environment
# ==========================================================

# Q2.1 Create an object called my_number containing one number.

# Q2.2 Create an object called my_text containing one character string.

# Q2.3 Create an object called my_factor containing one factor value.
# Hint: use factor().

# Q2.4 Use class() to check the class of the three objects.

# ==========================================================
# 3. Operations with existing objects
# ==========================================================

# Q3.1 Create two objects called budget_2025 and budget_2026.
# Choose any numerical values.


# Q3.2 Create a new object called budget_change containing the difference
# between budget_2026 and budget_2025.

# Q3.3 Create a new object called budget_growth_percent containing the
# percentage change between budget_2025 and budget_2026.
# Formula: (new value - old value) / old value * 100

# Q3.4 Print the result.

# ==========================================================
# 4. Understanding errors
# ==========================================================

# Q4.1 Run the following line. It should produce an error.
# my_budget + 10

# Q4.2 In a comment, explain why the error happened.

#### There is no object called my_budget, so we add 10 to somethign that does not exist

# Q4.3 Fix the error by creating the missing object and running the operation again.

# Q4.4 Run the following line. Is there an error? What is the result?
# mean(c(1, 2, 3, NA))

# Q4.5 Now use the help page for mean().
# Hint: run ?mean in the console.
# Then compute the mean while ignoring the missing value.

# ==========================================================
# 5. Vectors
# ==========================================================

# Q5.1 Create a character vector called commune_names with at least four communes.

# Q5.2 Create a numerical vector called population with one population value for each commune.

# Q5.3 Compute the mean, minimum, and maximum population.

# Q5.4 Extract the first commune name from commune_names.

# Q5.5 Extract the first two population values from population.


# ==========================================================
# 6. Create a data frame
# ==========================================================

# Q6.1 Create a data frame called commune_data using data.frame().
# It should contain the two vectors commune_names and population.

# Q6.2 Inspect the data frame with the following functions:
# head()
# str()
# summary()
# nrow()
# ncol()

# Q6.3 Create a new variable called population_thousands.
# Hint: you can use the $ operator.

# ==========================================================
# 7. Write your first function
# ==========================================================

# Q7.1 Create a function called multiply_4_minus_10.
# The function should multiply a number by 4 and then substract 10, and print the result.


# Q7.2 Test the function with the values 4, 12, and 100.


# Q7.3 Apply the function to the vector population.

# ==========================================================
# 8. Install package and load a library
# ==========================================================

# 8.1 Install the devtools package
# install.packages("remotes")

# 8.2 install the RSwissPos package
# go to https://github.com/maxwaldo/RSwissPos and follow the instruction

# 8.3 Load the library in your environment

# 8.4 Try the getSwissvotes() function from the RSwissPos package

# 8.5 Read the help documentation of the getSwissvotes function with ?getSwissvotes

# What is this function doing? What do you get out of it?


# ==========================================================
# 10. Cumulative challenge
# ==========================================================

# Q10.1 Download the Swissvotes data set and assign it to the object "swissvotes"

# Q10.2 Which ballot proposal has the greatest share of support by the swiss population?
# Hint: use which.max(). Look at the correct variable to analyze in the Swissvotes codebook.


# Q10.3 Which ballot proposal has the lowest share of support by the swiss population?
# Hint: use which.min().

# Q10.4 How many initiative, mandatory and facultative referendums is in the Swissvotes database?

