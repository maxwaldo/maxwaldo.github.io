############################################################
# Applied Methods — Session 2
# Data manipulation and descriptive statistics
# Exercises
############################################################

# ==========================================================
# 0. Preparation
# ==========================================================

# Q0.1 install dplyr and tidyr
install.packages("dplyr")
install.packages("tidyr")

# Q0.2 load dplyr and tidyr in your session
library(dplyr)
library(tidyr)


# ==========================================================
# 1. Import the data
# ==========================================================

# Q1.1 Set working directory to Today's session.
setwd("~/Desktop/Teaching_Grading/Applied methods/Session 2")
# Q1.2 Verify you are in the correct directory
getwd()
# Q1.3 Import the data "Pop_Genève_1950-1999.csv" in an R object named pop_1950_1999.
pop_1950_1999 <- read.csv("data/Pop_Genève_1950-1999.csv")
# Q1.4 How many observation is there in this dataset? (Hint: use nrow())
nrow(pop_1950_1999)
print(paste("There are", nrow(pop_1950_1999), "municipalities in the data."))
# Q1.5 How many variables is there in this dataset? (Hint: use ncol())
ncol(pop_1950_1999)
print(paste("There are", ncol(pop_1950_1999), "variables in the data."))

# ==========================================================
# 2. Inspect the data
# ==========================================================

# Q2.1 Inspect the data with summary().
summary(pop_1950_1999)
# Q2.2 View the data in a new pane.
View(pop_1950_1999)
# Q2.3 Look at the five first observation of the first variable Mun.
head(pop_1950_1999$Mun)

# ==========================================================
# 3. Clean the data
# ==========================================================

# Q3.1 What is the class of the first variable?
class(pop_1950_1999$Mun)
# Q3.2 What is the class of the second variable?
class(pop_1950_1999$X1950)
# Q3.3 Create a new variable named XY1950, that is the numeric form of the second variable. What message do you get? and why?
# Hint: use as.numeric()
pop_1950_1999 <- pop_1950_1999 %>% 
  mutate(XY1950 = as.numeric(X1950))
# Q3.4 Create a new variable named XY1951, that is the numeric form of the the third variable with no missing value.
# Hint: use the gsub() function.
pop_1950_1999 <- pop_1950_1999 %>% 
  mutate(XY1951 = as.numeric(gsub("'", "",X1951)))


# ==========================================================
# 4. Recode data
# ==========================================================

# Q4.0 First run the following command to transform all year variables in numeric variables

pop_1950_1999[,2:(ncol(pop_1950_1999)-2)] <- lapply(pop_1950_1999[,2:(ncol(pop_1950_1999)-2)], 
                                                    function(x) {
  x <- as.numeric(gsub("'", "", x))
})

# Q4.1 Create a variable that has the sum of the population in municipalities between 1950 and 1959.
# Q4.2 Create a variale that gives the maximal value of population for the year 1973.
# Q4.3 Create a variable that takes value 1 if the name of a municipality start with an A or a G and 0 otherwise.
# Hint: use the substr() function
# Q4.4 Use the table() function to report how many municipalities' name start with a A or a G.

pop_1950_1999 <- pop_1950_1999 %>% 
  mutate(sum_pop_1950_1999 = rowSums(pick(starts_with("X1")), na.rm = TRUE), # 4.1
         max_1973 = max(X1973), # 4.2
         start_with_A_or_G = ifelse(substr(Mun, 1, 1) %in% c("A", "G"), 1, 0)) # 4.3

table(pop_1950_1999$start_with_A_or_G) #4.4

# ==========================================================
# 5. Merge datasets
# ==========================================================

# Q5.1 Import the data named "Pop_Genève_2000-2025.csv" in an R object named pop_2000_2025
pop_2000_2025 <- read.csv("data/Pop_Genève_2000-2025.csv")
# Q5.1b Import again the data named "Pop_Genève_1950-1999.csv" in an R object named pop_1950_1999
# This will overwrite the old environment
pop_1950_1999 <- read.csv("data/Pop_Genève_1950-1999.csv")
# Q5.2 Report the correct identifier between the two municipalities
# Q5.3 Merge the environement pop_1950_1999 and pop_2000_2025 into a new object called data_pop.
data_pop <- merge(pop_1950_1999, pop_2000_2025, by = "Mun")

# ==========================================================
# 6. Select, filter and arrange
# ==========================================================

# Q6.1 Filter observations with more than 1000 inhabitants in 1960 in a environement named "data_pop_filter".
# How many municipalities had more than 1000 inhabitants in 1960?
data_pop_filter <- data_pop %>% 
  filter(as.numeric(gsub("'","",X1960))>1000)
print(paste("In 1960, there were", nrow(data_pop_filter), "municipalities with more than 1000 inhabitants."))
# Q6.2 Arrange observations by the number of inhabitants in 1999 in a environement named "data_pop_arrange"
# What are the five municipalities with the largest inhabitants in 1999?
data_pop_arrange <- data_pop %>% 
  arrange(desc(as.numeric(gsub("'","",X1999))))
head(data_pop_arrange$Mun)

# ==========================================================
# 7. Reshape data
# ==========================================================

# Q7.1 Is the current data_pop object a long or wide data ?

print("It is a wide data")

# Q7.2 What are the names and values of variables ?

print("The name of the variables is the year, the value is the population")

# Q7.3 Using the pivot_longer function, reshape the data with 3 variable
# Mun: Name of the municipality
# year: Year of observation
# pop: Number of inhabitants in the municipality

data_pop_long <- data_pop %>% 
  pivot_longer(cols = 2:ncol(data_pop),
               names_to = "year",
               names_prefix = "X", 
               values_to = "pop")

# Q7.3b change the class of the variable pop to a numeric variable with no missing.
data_pop_long <- data_pop_long %>% 
  mutate(pop = as.numeric(gsub("'", "", pop)))

# Q7.3c change the class of the variable year to a numeric variable with no missing.
# Do you have a message, try to figure out why!
data_pop_long <- data_pop_long %>% 
  mutate(year = as.numeric(year))

# Q7.3d exclude the observation with NAs on the variable year from the data
data_pop_long <- data_pop_long %>% 
  filter(is.na(year)==F)

# Q7.4 What is the unit of observation of the new data?

print("The unit of observation is a municipality in a year")

# Q7.5 Create a variable named "pop2000" with the number of people in the municipalities in 2000

data_pop_long <- data_pop_long %>% 
  mutate(pop2000 = rep(pop[year == 2000], each = nrow(data_pop_long)/46))

# Q7.6 Create a variable named "ratio_pop2000" indicating the ratio between each year inhabitant in municipality and the year 2000.

data_pop_long <- data_pop_long %>% 
  mutate(ratio_pop2000 = pop/pop2000)


# Q7.7 Which municipality had the greatest increase in the share of its population between 2000 and 2010?

data_pop_long %>% 
  arrange(desc(ratio_pop2000)) %>% 
  filter(year==2010) %>% 
  head()

# ==========================================================
# 8. Compute descriptive statistics
# ==========================================================

# Q8.1 What is the scope of the variable pop in the long data?
print(paste("The range is", max(data_pop_long$pop, na.rm = T)-(min(data_pop_long$pop, na.rm = T))))
# Q8.2 What is the mean of the variable pop in the long data?
mean(data_pop_long$pop, na.rm=T)
# Q8.3 What is the median of the variable pop in the long data?
median(data_pop_long$pop, na.rm=T)
# Q8.4 What is the 10th percentil of the variable pop in the long data?
quantile(data_pop_long$pop, .1, na.rm = T)

# ==========================================================
# 9. Different levels of analysis
# ==========================================================

# Q9.1 Compute the average population in a variable named "av.pop" in the data_pop environement.
# use the summary function to see the results.
# Q9.2 Compute the average for each municipality in a variable named "av.pop.mun" in the data_pop environement
# use the summary function to see the results.
# Q9.3 Compute the average for each year in a variable named "av.pop.year" in the data_pop environement
# use the summary function to see the results.
# Q9.4 Compute the average increase in population for municipalities with a population above or under the median in 1950.
# use the summary function to see the results.

data_pop_long <- data_pop_long %>% 
  mutate(av.pop =  mean(pop,na.rm=T)) %>% 
  group_by(Mun) %>% 
  mutate(av.pop.mun = mean(pop,na.rm=T)) %>% 
  ungroup() %>% 
  group_by(year) %>% 
  mutate(av.pop.year = mean(pop,na.rm=T)) %>% 
  ungroup()

summary(data_pop_long$av.pop)
summary(data_pop_long$av.pop.mun)
summary(data_pop_long$av.pop.year)

# ==========================================================
# 10. Check data manipulation outputs 
# ==========================================================

# For each question, think why, and check whether this is correct

# Q10.1 How many municipality are there in the data_pop environment?
print(length(unique(data_pop_long$Mun)))
# Q10.2 How many time points are there in the data_pop environment?
print(length(unique(data_pop_long$year)))
# Q10.3 How many observation should there be in a long data set?
print(length(unique(data_pop_long$Mun)) * length(unique(data_pop_long$year)))
# Q10.4 How many different values are possible in the av.pop.mun variable?
print(length(unique(data_pop_long$Mun)))
# Q10.5 How many observation per value is there in the av.pop.year variable?
print(length(unique(data_pop_long$year)))
# Q10.6 How many different values are possible for the variable av.pop?
print(1)

# ==========================================================
# 11. Cumulative coding challenge. 
# ==========================================================

# Q11.1 Go to the OCSTAT website and download the file called "Véhicules en circulation, selon la catégorie, dans le canton de Genève, par mois,"
# Hint: Category 11, mobilité.
# Q11.2 Import the data in Excel and use appropriate processing steps to import the data. 
# Hint 1: install the package readxl
install.packages("readxl")
library(readxl)
# Hint 2: Open the file and look at the content, some processing may need to be done
data_v <- read_xlsx("~/Downloads/T_11_02_04.xlsx", skip = 10, col_names = c("Year", "Jan", "Feb", 
                                                                            "March", "April", "May",
                                                                            "June", "July", "Aug", "Sept",
                                                                            "Oct", "Nov", "Dec"))

# Q11.3 Reshape the data so it has the type of vehicule as variables and the year x month as unit of observation
# Hint 1: You may need to creat the variable for vehicule type yourself. 
# Hint 2: You may need to reshape th data twice

data_v <- data_v[1:144,]

types <- data_v[substr(data_v$Year,1,1)!="2",]$Year

data_v <- data_v %>% 
  mutate(type = rep(types, each=16))

data_v <- data_v[substr(data_v$Year,1,1)=="2",]

data_v_l <- data_v %>% 
  pivot_longer(cols = c(2:(ncol(data_v)-1)),
               names_to = "Months",
               values_to = "Number") 

data_v_l_w <- data_v_l %>% 
  pivot_wider(names_from = "type",
              values_from = "Number",
              names_prefix = "type_")


# Q11.4 Compute the number of Camion by type for 1100 habitants. 
# Hint: merge it with the population data we worked on, and compute the variable. 

data_pop_canton <- data_pop_long %>% 
  filter(Mun=="Canton")

data_v <- merge(data_v_l_w, data_pop_canton, by.x="Year", by.y="year")

data_v <- data_v %>% 
  mutate(camion_per_1000 = as.numeric(type_Camions)/pop*1000)

# Q11.5 In what month and year were the number of camion for a 1000 inhabitants the largest?
data_v %>% 
  filter(camion_per_1000==max(camion_per_1000, na.rm=T)) %>% 
  View()

# Or

data_v %>% 
  arrange(desc(camion_per_1000)) %>% 
  head()

# Q11.6 Compute the yearly average of vehicule number for each vehicule type. 
data_v <- data_v %>% 
  group_by(Year) %>% 
  mutate(av_total = mean(as.numeric(type_Total), na.rm=T),
         av_tourism = mean(as.numeric(`type_Voitures de tourisme (2)`), na.rm=T),
         av_delivery = mean(as.numeric(`type_Voitures de livraison (3)`), na.rm=T),
         av_camion = mean(as.numeric(type_Camions), na.rm=T),
         av_buses = mean(as.numeric(`type_Cars, autobus`), na.rm=T),
         av_moto = mean(as.numeric(type_Motocycles), na.rm=T),
         av_small_moto = mean(as.numeric(`type_Motocycles légers (4)`), na.rm=T),
         av_other = mean(as.numeric(`type_Autres (5)`), na.rm=T),
         av_new_car = mean(as.numeric(`type_Voitures neuves (6)`), na.rm=T))

# Q11.7 What is the year with the highest number of vehicule for each type of vehicule?

data_v[which.max(data_v$av_total),]$Year
data_v[which.max(data_v$av_tourism),]$Year
data_v[which.max(data_v$av_delivery),]$Year
data_v[which.max(data_v$av_camion),]$Year
data_v[which.max(data_v$av_buses),]$Year
data_v[which.max(data_v$av_moto),]$Year
data_v[which.max(data_v$av_small_moto),]$Year
data_v[which.max(data_v$av_other),]$Year
data_v[which.max(data_v$av_new_car),]$Year



