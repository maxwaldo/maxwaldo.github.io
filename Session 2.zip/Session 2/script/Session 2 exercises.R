############################################################
# Applied Methods — Session 2
# Data manipulation and descriptive statistics
# Exercises
############################################################

# ==========================================================
# 0. Preparation
# ==========================================================

# Q0.1 install dplyr, tidyr, and ggplot2
# Q0.2 load dplyr, tidyr, and ggplot2 in your session


# ==========================================================
# 1. Import the data
# ==========================================================

# Q1.1 Set working directory to Today's session.
# Q1.2 Verify you are in the correct directory
# Q1.3 Import the data "Pop_Genève_1950-1999.csv" in an R object named pop_1950_1999.
# Q1.4 How many observation is there in this dataset? (Hint: use nrow())
# Q1.5 How many variables is there in this dataset? (Hint: use ncol())

# ==========================================================
# 2. Inspect the data
# ==========================================================

# Q2.1 Inspect the data with summary().
# Q2.2 View the data in a new pane.
# Q2.3 Look at the five first observation of the first variable Mun.

# ==========================================================
# 3. Clean the data
# ==========================================================

# Q3.1 What is the class of the first variable?
# Q3.2 What is the class of the second variable?
# Q3.3 Create a new variable named XY1950, that is the numeric form of the second variable. What message do you get? and why?
# Hint: use as.numeric()
# Q3.4 Create a new variable named XY1951, that is the numeric form of the the third variable with no missing value.
# Hint: use the gsub() function.


# ==========================================================
# 4. Recode data
# ==========================================================

# Q4.0 First run the following command to transform all year variables in numeric variables

data_1950_1999[,2:(ncol(data_1950_1999)-2)] <- lapply(data_1950_1999[,2:(ncol(data_1950_1999)-2)], 
                                                    function(x) {
  x <- as.numeric(gsub("'", "", x))
})

# Q4.1 Create a variable that has the sum of the population in municipalities between 1950 and 1959.
# Q4.2 Create a variale that gives the maximal value of population for the year 1973.
# Q4.3 Create a variable that takes value 1 if the name of a municipality start with an A or a G and 0 otherwise.
# Hint: use the substr() function
# Q4.4 Use the table() function to report how many municipalities' name start with a A or a G.


# ==========================================================
# 5. Merge datasets
# ==========================================================

# Q5.1 Import the data named "Pop_Genève_2000-2025.csv" in an R object named pop_2000_2025
# Q5.1b Import again the data named "Pop_Genève_1950-1999.csv" in an R object named pop_1950_1999
# This will overwrite the old environment
# Q5.2 Report the correct identifier between the two municipalities
# Q5.3 Merge the environement pop_1950_1999 and pop_2000_2025 into a new object called data_pop.

# ==========================================================
# 6. Select, filter and arrange
# ==========================================================

# Q6.1 Filter observations with more than 1000 inhabitants in 1960 in a environement named "data_pop_filter".
# How many municipalities had more than 1000 inhabitants in 1960?
# Q6.2 Arrange observations by the number of inhabitants in 1999 in a environement named "data_pop_arrange"
# What are the five municipalities with the largest inhabitants in 1999?


# ==========================================================
# 7. Reshape data
# ==========================================================

# Q7.1 Is the current data_pop object a long or wide data ?
# Q7.2 What are the names and values of variables ?
# Q7.3 Using the pivot_longer function, reshape the data with 3 variable
# Mun: Name of the municipality
# year: Year of observation
# pop: Number of inhabitants in the municipality

# Q7.3b change the class of the variable pop to a numeric variable with no missing.
# Q7.3c change the class of the variable year to a numeric variable with no missing.
# Do you have a message, try to figure out why!
# Q7.3d exclude the observation with NAs on the variable year from the data
# Q7.4 What is the unit of observation of the new data?
# Q7.5 Create a variable named "pop2000" with the number of people in the municipalities in 2000
# Q7.6 Create a variable named "ratio_pop2000" indicating the ratio between each year inhabitant in municipality and the year 2000.
# Q7.7 Which municipality had the greatest increase in the share of its population between 2000 and 2010?


# ==========================================================
# 8. Compute descriptive statistics
# ==========================================================

# Q8.1 What is the scope of the variable pop in the long data?
# Q8.2 What is the mean of the variable pop in the long data?
# Q8.3 What is the median of the variable pop in the long data?
# Q8.4 What is the 10th percentil of the variable pop in the long data?

# ==========================================================
# 9. Different levels of analysis
# ==========================================================

# Q9.1 Compute the average population in a variable named "av.pop" in the data_pop environement.
# use the summary function to see the results.
# Q9.2 Compute the average for each municipality in a variable named "av.pop.mun" in the data_pop environement
# use the summary function to see the results.
# Q9.3 Compute the average for each year in a variable named "av.pop.year" in the data_pop environement
# use the summary function to see the results.
# Q9.4 Compute the average increase in population for municipalities with a population above or under the median in 1950.
# use the summary function to see the results.


# ==========================================================
# 10. Check data manipulation outputs 
# ==========================================================

# For each question, think why, and check whether this is correct

# Q10.1 How many municipality are there in the data_pop environment?
# Q10.2 How many time points are there in the data_pop environment?
# Q10.3 How many observation should there be in a long data set?
# Q10.4 How many different values are possible in the av.pop.mun variable?
# Q10.5 How many observation per value is there in the av.pop.year variable?
# Q10.6 How many different values are possible for the variable av.pop?

# ==========================================================
# 11. Cumulative coding challenge. 
# ==========================================================

# Q11.1 Go to the OCSTAT website and download the file called "Véhicules en circulation, selon la catégorie, dans le canton de Genève, par mois,"
# Hint: Category 11, mobilité.
# Q11.2 Import the data in Excel and use appropriate processing steps to import the data. 
# Hint 1: install the package readxl
# Hint 2: Open the file and look at the content, some processing may need to be done
# Q11.3 Reshape the data so it has the type of vehicule as variables and the year x month as unit of observation
# Hint 1: You may need to creat the variable for vehicule type yourself. 
# Hint 2: You may need to reshape th data twice
# Q11.4 Compute the number of Camion by type for 1100 habitants. 
# Hint: merge it with the population data we worked on, and compute the variable. 
# Q11.5 In what month and year were the number of camion for a 1000 inhabitants the largest?
# Q11.6 Compute the yearly average of vehicule number for each vehicule type. 
# Q11.7 What is the year with the highest number of vehicule for each type of vehicule?



