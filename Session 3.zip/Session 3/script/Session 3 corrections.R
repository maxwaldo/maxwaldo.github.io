############################################################
# Applied Methods — Session 3
# Data vizualization
# Exercises
############################################################

# ==========================================================
# 0. Preparation
# ==========================================================

### Preparing the set up

# Q0.1 install ggplot2 and sf
install.packages(c("ggplot2", "sf"))

# Q0.2 load dplyr, tidyr, ggplot2 and sf into your session
library(ggplot2)
library(dplyr)
library(tidyr)

# Q0.3 set the working directory to session 3
setwd("~/Desktop/Teaching_Grading/Applied methods/Session 3")

### Importing the data

# Q0.4 Import the "data_migration.csv" fil from the data folder and store it into an object named "mun_migration" and inspect the data
mun_migration <- read.csv("data/data_migration.csv")
summary(mun_migration)

# Q0.5 Import the "data_mun_typologies.csv" from the data folder and store it into an object named "mun_type" and inspect the data
mun_type <- read.csv("data/data_mun_typologie.csv")
summary(mun_type)

# Q0.6 Import the "mun_10million.csv" from the data folder and store it into an object named "mun_10million" and inspect the data
mun_10million <- read.csv("data/mun_10million.csv")
summary(mun_10million)


### Recoding variables

# Q0.7 in the mun_migration data, create two variables:
#  the share of immigrants in a municipality in a variable called migration share.
#  A variables named mig_cat indicating whether the share of migrants is under 2%, between 2 and 5%, between 5 and 10% and more than 10 percent
mun_migration <- mun_migration %>% 
  mutate(migration_share = Immigrants/Residents,
         mig_cat = case_when(migration_share<.02 ~ "Less than 2%",
                             migration_share>=.02 & migration_share<.05 ~ "Between 2% and 5%",
                             migration_share>=.05 & migration_share<.1 ~ "Between 5% and 10%",
                             migration_share>=.1 ~ "More than 10%"))


# Q0.8 Run the following command to create another more compact category for municipalities
mun_type <- mun_type %>% 
  mutate(cat_suburb = case_when(cat25==111~"Ville-centre",
                                cat25==112~"Commune suburbaine",
                                cat25==113~"Commune suburbaine",
                                cat25==121~"Ville-centre",
                                cat25==122~"Commune suburbaine",
                                cat25==123~"Commune suburbaine",
                                cat25==134~"Ville isolée",
                                cat25==136~"Ville isolée",
                                cat25==137~"Ville isolée",
                                cat25==216~"Commune périurbaine",
                                cat25==217~"Commune périurbaine",
                                cat25==226~"Commune périurbaine",
                                cat25==227~"Commune périurbaine",
                                cat25==235~"Commune périurbaine",
                                cat25==236~"Commune périurbaine",
                                cat25==237~"Commune périurbaine",
                                cat25==314~"Commune rurale",
                                cat25==316~"Commune rurale",
                                cat25==317~"Commune rurale",
                                cat25==325~"Commune rurale",
                                cat25==326~"Commune rurale",
                                cat25==327~"Commune rurale",
                                cat25==334~"Commune rurale",
                                cat25==335~"Commune rurale",
                                cat25==338~"Commune rurale"))

### Merging data sets 

# Q0.9 merge de mun_10million and the mun_migration data together in an object call data_10_migration. 
# For the mun_migration, keep only observation from the last year.
data_10_migration <- merge(mun_10million, mun_migration[mun_migration$year==2000,], by.x="NumberMun", by.y="mun_id")

# Q0.10 merge de mun_10million and the mun_type data together in an object call data_10_type 
data_10_type <- merge(mun_10million, mun_type, by.x="NumberMun", by.y="id_place")

# Q0.11 merge de data_10_type and the mun_migration data together in an object call data_all. 
# For the mun_migration, keep only observation from the last year.
data_all <- merge(data_10_type, mun_migration[mun_migration$year==2000,], by.x = "NumberMun", by.y="mun_id")




# ==========================================================
# 1. Correct the plot
# ==========================================================

# Q1.1 You want to plot the distribution of vote share for the 10 million initiative across municipalities with an histogram
# Here is the initial code
ggplot(mun_10million)+
  geom_bar(YesPercent)

# Using your knowledge on ggplot grammar correct the plot
# Hint 1: What is the aestetic?
# Hint 2: How do we produce histograms?
ggplot(mun_10million, aes(x=YesPercent))+
  geom_histogram()

# Q1.2 For your second plot, you want to plot the number of municipality for each type we coded in Q0.8.
# Here is you code
ggplot()+
  geom_bar(aes(x=type))

# Fix the plot so it shows the correct plot

ggplot(mun_type, aes(x=cat_suburb))+
  geom_bar()

# ==========================================================
# 2. Improve the bar plot
# ==========================================================

# Q2.1 You want to see how many municipalities have migration in 2000 that was under 2%, between 2% and 5%, between 5% and 10% and above 10%
# Using the mun_migration data, generate a bar plot that does that

ggplot(mun_migration %>% 
         filter(year==2000), 
       aes(x=mig_cat))+
  geom_bar() 


# Q2.2 Arrange it by the number of observation in each category
# Q2.3 Provide accurate axis titles
# Q2.4 Provide a descriptive title
# Q2.5 Change the fill to light grey and the color to blue
# Q2.6 Use another theme than the default one.

ggplot(mun_migration %>% 
         filter(year==2000) %>% 
         count(mig_cat), 
       aes(x=reorder(mig_cat, n), y=n))+
  geom_col(fill="light grey", color = "blue")+ # Q2.5
  labs(x = "Migration share",
       y= "Number of municipalities", # Q2.3
       title = "Distribution of municipalities by foreign immigration share in 2000")+ # Q2.4
  theme_minimal() # Q2.6


# ==========================================================
# 3. Plot the municipal residing population in 1970
# ==========================================================

# Q3.1 Generate an histogram for the municipal resident population in 1970

# Q3.2 Change the scale of the x axis to a log in base 10
# Q3.3 Change the fill and color of the histogram
# Q3.4 Change the number of bins to 100
# Q3.5 Change the x and y labels
# Q3.6 Change the y axis values so it represents the proportion instead of the count

ggplot(mun_migration[mun_migration$year==1970,], 
       aes(x=Residents, 
           y = after_stat(count/sum(count)), # 3.6
           group = 1))+
  geom_histogram(fill="lightgrey", # 3.3
                 color = "red", # 3.3
                 bins = 100)+ # 3.4
  scale_x_log10()+ # 3.2
  labs(x="Residing population")+ #3.5
  theme_minimal() 


# Q3.7 Now provide a boxplot of this data
ggplot(mun_migration[mun_migration$year==1970,], 
       aes(x=Residents))+
  geom_boxplot(fill="lightgrey", 
                 color = "red", 
                 bins = 100)+
  scale_x_log10()+ 
  labs(x="Residing population",
       y="Share on municipalities")+
  theme_minimal()
# Q3.8 Plot the cumulative distribution
ggplot(mun_migration[mun_migration$year==1970,], 
       aes(x=Residents))+
  stat_ecdf()+
  scale_x_log10()+ 
  labs(x="Residing population",
       y="Share on municipalities")+
  theme_minimal()



# ==========================================================
# 4. Plot two continuous variables
# ==========================================================

# Q4.1 Use ggplot to create a scatter plot with the share of immigration in 2000 on the x axis and the support for the 10 milion initiative in the y axis
# Hint: You should maybe merge some datasets

ggplot(data_10_migration, aes(x=migration_share, y=YesPercent))+
  geom_point()

# Q4.2 Add the linear trend between these two variables
ggplot(data_10_migration, aes(x=migration_share, y=YesPercent))+
  geom_point()+
  geom_smooth(method = "lm")

# Q4.3 Explain what you observe is the relationship between the share of immigrants and the support for the 10 milion initiative is. 
# Q4.4 Pimp your plots by providing axis labels, another theme and change the size and colors of the dots. 
ggplot(data, aes(x=Immigrants/Residents, y=YesPercent))+
  geom_point(color = "blue", size = .3)+
  geom_smooth(method = "lm")+
  theme_minimal()+
  labs(x="Share of immigrants in 2000", 
       y="Percent of the population in favor of the 10 million initiative")
  
# Q4.5 Add an horizontal line at the 50 percent threshold on the y axis
# Hint: Look the command geom_hline()
ggplot(data, aes(x=Immigrants/Residents, y=YesPercent))+
  geom_point(color = "blue", size = .3)+
  geom_smooth(method = "lm")+
  theme_minimal()+
  labs(x="Share of immigrants in 2000", 
       y="Percent of the population in favor of the 10 million initiative")+
  geom_hline(yintercept = 50, color = "purple")

# ==========================================================
# 5. One categorical and one continuous
# ==========================================================

# Q5.1 Make a boxplot with the share of municipal support for the 10 million initiative across different types of municipalities
# Hint: you may want to merge data on the 10 million initiative with the classification of municipalities

ggplot(data_10_type, aes(x=cat_suburb, y=YesPercent))+
  geom_boxplot()+
  geom_jitter(alpha=.5, size = .2)
  

# ==========================================================
# 6. Two categorical
# ==========================================================

# Q6.1 Plot the proportion of the type of municipality by canton

ggplot(mun_type, aes(x=canton_abv, 
                     fill=cat_suburb, y=after_stat(prop)))+
  geom_bar(position="fill")

# 6.2 change the fill colors so that the color transparancy is set to .4 and color are as follows:
# Commune periurbaine are blue
# Commune rurale are dark green
# Commune suburbaine are red
# Villes isolée are grey
# Villes centre are black

ggplot(mun_type, aes(x=canton_abv, 
                     fill=cat_suburb, y=after_stat(prop)))+
  geom_bar(position="fill", alpha=.4)+
  scale_fill_manual(values = c("blue", "dark green", "red", "grey", "black"))

# ==========================================================
# 7. Time trends
# ==========================================================

# Q7.1 plot the share of the migrating population for the muninipality number 13 for each year available in the data. 

ggplot(mun_migration[mun_migration$mun_id==13,], aes(x=year, y=Immigrants/Residents))+
  geom_line()

# Q7.2 do the same for three municipalities and use the group parameter to make three different lines

ggplot(mun_migration[mun_migration$mun_id %in% sample(mun_migration$mun_id, 3, replace = T),], 
       aes(x=year, y=Immigrants/Residents, group = mun_id))+
  geom_line()


# ==========================================================
# 8. More than two variables
# ==========================================================

# Q8.1 Open the figure in the Figure folder and reproduce it as well as possible. Save it into a .png file. 
# Hint 1: Be careful about the order of the categorical variable
# Hint 2: X axis scope is reduced
data_all$cat_suburb <- factor(data_all$cat_suburb, levels=c("Commune rurale",
                                                            "Commune suburbaine",
                                                            "Commune périurbaine",
                                                            "Ville isolée",
                                                            "Ville-centre"))

png("Figure/Figure to reproduce.png", width=3000, height=1500, res = 300)
ggplot(data_all, aes(x=Immigrants/Residents, y=YesPercent))+
  geom_point(size = .3, alpha=.5, color = "red")+
  geom_smooth(method="lm")+
  scale_x_continuous(limits = c(0,0.12))+
  facet_wrap(~cat_suburb)+
  theme_minimal()+
  labs(title = "Relation between share of immigration and support for the 10 million initiative by type of municipality.",
       x="Share of immigrants",
       y="Support for the 10 million initiative (in %)")
dev.off()

