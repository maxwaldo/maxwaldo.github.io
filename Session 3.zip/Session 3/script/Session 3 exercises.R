############################################################
# Applied Methods — Session 3
# Data vizualization
# Exercises
############################################################

# ==========================================================
# 0. Preparation
# ==========================================================

### Preparing the set up

# Q0.1 install ggplot2 and sf

# Q0.2 load dplyr, tidyr, ggplot2 and sf into your session

# Q0.3 set the working directory to session 3

### Importing the data

# Q0.4 Import the "data_migration.csv" fil from the data folder and store it into an object named "mun_migration" and inspect the data

# Q0.5 Import the "data_mun_typologies.csv" from the data folder and store it into an object named "mun_type" and inspect the data

# Q0.6 Import the "mun_10million.csv" from the data folder and store it into an object named "mun_10million" and inspect the data


### Recoding variables

# Q0.7 in the mun_migration data, create two variables:
#  the share of immigrants in a municipality in a variable called migration share.
#  A variables named mig_cat indicating whether the share of migrants is under 2%, between 2 and 5%, between 5 and 10% and more than 10 percent


# Q0.8 Run the following command to create another more compact category for municipalities
mun_type <- mun_type %>% 
  mutate(cat_suburb = case_when(cat25==111~"Ville-centre",
                                cat25==112~"Commune suburbaine",
                                cat25==113~"Commune suburbaine",
                                cat25==121~"Ville-centre",
                                cat25==122~"Commune suburbaine",
                                cat25==123~"Commune suburbaine",
                                cat25==134~"Ville isolée",
                                cat25==136~"Ville isolée",
                                cat25==137~"Ville isolée",
                                cat25==216~"Commune périurbaine",
                                cat25==217~"Commune périurbaine",
                                cat25==226~"Commune périurbaine",
                                cat25==227~"Commune périurbaine",
                                cat25==235~"Commune périurbaine",
                                cat25==236~"Commune périurbaine",
                                cat25==237~"Commune périurbaine",
                                cat25==314~"Commune rurale",
                                cat25==316~"Commune rurale",
                                cat25==317~"Commune rurale",
                                cat25==325~"Commune rurale",
                                cat25==326~"Commune rurale",
                                cat25==327~"Commune rurale",
                                cat25==334~"Commune rurale",
                                cat25==335~"Commune rurale",
                                cat25==338~"Commune rurale"))

### Merging data sets 

# Q0.9 merge de mun_10million and the mun_migration data together in an object call data_10_migration. 
# For the mun_migration, keep only observation from the last year.

# Q0.10 merge de mun_10million and the mun_type data together in an object call data_10_type 

# Q0.11 merge de data_10_type and the mun_migration data together in an object call data_all. 
# For the mun_migration, keep only observation from the last year.




# ==========================================================
# 1. Correct the plot
# ==========================================================

# Q1.1 You want to plot the distribution of vote share for the 10 million initiative across municipalities with an histogram
# Here is the initial code
ggplot(mun_10million)+
  geom_bar(YesPercent)

# Using your knowledge on ggplot grammar correct the plot
# Hint 1: What is the aestetic?
# Hint 2: How do we produce histograms?

# Q1.2 For your second plot, you want to plot the number of municipality for each type we coded in Q0.8.
# Here is you code
ggplot()+
  geom_bar(aes(x=type))

# Fix the plot so it shows the correct plot


# ==========================================================
# 2. Improve the bar plot
# ==========================================================

# Q2.1 You want to see how many municipalities have migration in 2000 that was under 2%, between 2% and 5%, between 5% and 10% and above 10%
# Using the mun_migration data, generate a bar plot that does that

# Q2.2 Arrange it by the number of observation in each category
# Q2.3 Provide accurate axis titles
# Q2.4 Provide a descriptive title
# Q2.5 Change the fill to light grey and the color to blue
# Q2.6 Use another theme than the default one.


# ==========================================================
# 3. Plot the municipal residing population in 1970
# ==========================================================

# Q3.1 Generate an histogram for the municipal resident population in 1970

# Q3.2 Change the scale of the x axis to a log in base 10
# Q3.3 Change the fill and color of the histogram
# Q3.4 Change the number of bins to 100
# Q3.5 Change the x and y labels
# Q3.6 Change the y axis values so it represents the proportion instead of the count

# Q3.7 Now provide a boxplot of this data

# Q3.8 Now, plot the cumulative distribution



# ==========================================================
# 4. Plot two continuous variables
# ==========================================================

# Q4.1 Use ggplot to create a scatter plot with the share of immigration in 2000 on the x axis and the support for the 10 milion initiative in the y axis

# Q4.2 Add the linear trend between these two variables

# Q4.3 Explain what you observe is the relationship between the share of immigrants and the support for the 10 milion initiative is. 
# Q4.4 Pimp your plots by providing axis labels, another theme and change the size and colors of the dots. 

# Q4.5 Add an horizontal line at the 50 percent threshold on the y axis

# ==========================================================
# 5. One categorical and one continuous
# ==========================================================

# Q5.1 Make a boxplot with the share of municipal support for the 10 million initiative across different types of municipalities


# ==========================================================
# 6. Two categorical
# ==========================================================

# Q6.1 Plot the proportion of the type of municipality by canton

# 6.2 change the fill colors so that the color transparancy is set to .4 and color are as follows:
# Commune periurbaine are blue
# Commune rurale are dark green
# Commune suburbaine are red
# Villes isolée are grey
# Villes centre are black

# ==========================================================
# 7. Time trends
# ==========================================================

# Q7.1 plot the share of the migrating population for the muninipality number 13 for each year available in the data. 

# Q7.2 do the same for three municipalities and use the group parameter to make three different lines


# ==========================================================
# 8. More than two variables
# ==========================================================

# Q8.1 Open the figure in the Figure folder and reproduce it as well as possible. Save it into a .png file. 
# Hint 1: Be careful about the order of the categorical variable
# Hint 2: X axis scope is reduced

