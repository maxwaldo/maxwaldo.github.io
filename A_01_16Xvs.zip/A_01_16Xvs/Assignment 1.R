############################################################
# Applied Methods
# Assignment 1
# Data manipulation and visualizaton
############################################################
# 0. Load these two libraries
library(dplyr)
library(ggplot2)

# ==========================================================
# 1. The surface of vignard across cantons and time (3pts)
# ==========================================================

# In the data folder, you'll find a fil named "vignard.csv".
################################################################################
###### A. Import this dataset, you should have a dataset with ##################
################################################################################
## 884 observations
## 4 variables


# The four variables are:
## Canton: Abréaviation of the canton's name
## Year: The year of observation
## Total: The total surface (in ha) devoted to agriculture in the canton
## Vignard: The total surface (in ha) devoted to vignard in the canton

##############################################################################################################################################
##### B. Create a variable that gives the canton-year share of vignard surface compared to the total surface devoted for agriculture. ########
##############################################################################################################################################
## Divide the vignard surface by the total surface devoted to agriculture?



######################################################################################################
##### C. In which canton was the surface devoted to agriculture the largest in the year 2000? ########
######################################################################################################



###########################################################################################################################################
####### D. In what year did the canton of Zurich (ZH) had the largest share of vignard surface as surface devoted to agriculture? #########
###########################################################################################################################################



####################################################################################################################################################
###### E. Generate an histogram of the agricultural surface in canton since 2000 (do not take into account observations before the year 2000) ######
###### Provide accurate description of the axis in the plot ########################################################################################
####################################################################################################################################################


  
#######################################################################################################################################
#### F. Generate a scatter plot with on the x axis, the agricultural surface, and on the y axis, the share of vignard in year 2025. ###
#### Add a line that fits the linear trend between these two variables ################################################################
#### rescale the x axis in log 10 #####################################################################################################
#### Provide accurate description of the acis in the plot #############################################################################
#######################################################################################################################################



#############################################################################################################################
####### G. Generate a line plot with the evolution of the sahre of vignard in the canton of Geneva over time. ###############
####### Provide accurate description of the acis in the plot ################################################################
#############################################################################################################################



# ==========================================================
# 2. Expenses in education (3pts)
# ==========================================================

# In the data folder, you'll find a fil named "education expense data.csv".
# You'll also find another file named "education expense data_by educ levels.csv".

################################################################################
###### A. Import these two dataset. ############################################
###### You should have one dataset with ########################################
###### 884 observations ########################################################
###### 3 variables #############################################################

###### And the other with ######################################################
###### 5304 observations #######################################################
###### 4 variables #############################################################
################################################################################



#########################################################################################
##### B. Adapt the following command so you can merge the two datasets ##################
#########################################################################################

# Hint: You may not need to modify the command depending the name you gave your object with the data. 
educ_data_all <- merge(educ_data, educ_data_by_levels, by=c("Canton", "Year"))

## The merged dataset should have 
## 5304 observations
## 5 variables

# The five varables are:
## Canton: Abréaviation of the canton's name
## Year: The year of observaton
## Expenses_total: The total amont spend on education in the canton year
## EducLevel: The level of formation for which the amont was spent
## Expenses: The amont that was spend on the specific degree for a cantonyear


############################################################################################################################
####### C. Create a new variable that gives the share of expense by levels  ################################################
####### Divide the amont spend for a specific level by the overall expenses. Be careful about the class of the variables. ##
############################################################################################################################



############################################################################################################################
##### D. In which year did the canton of Vaud (VD) had the greatest expense for the level "Hautes écoles"? #################
############################################################################################################################


############################################################################################################################
###### E. Is this the same year as the one the canton spent the most on education overall? If not in what year was that ####
############################################################################################################################



###################################################################################################################################
### E. provide a plot that describe the distribution of the share of expenses across cantons and year for "École obligatoire". ####
###################################################################################################################################
## Hint: We saw that multiple plots are appropriate to decribe the distribution of such variable, choose one. 



#####################################################################################################################################################################
#### F. Create a line plot that indicate the evolution of the share of expenses for the different levels of education overtime in the canotn of Lucern (LU). ########
#### give different colors to the different groups and give appropriate labels to the axis and the legend. ##########################################################
#####################################################################################################################################################################



# ==========================================================
# BONUS. Expense in education and vignard (+1pt)
# ==========================================================


# Create a scatter plot that presents the relationship between the share of vignard and the share of expense for "Hautes écoles" 
# Add a line that presents the linear trend between the variables. 

